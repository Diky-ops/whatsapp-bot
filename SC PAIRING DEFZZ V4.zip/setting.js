module.exports = {
  name: "Defzz",
  version: "4.1.0",
  number: "",
  owner: {
    name: "Defzz",
    number: "6282375197753",
    whatsapp: "6282375197753@s.whatsapp.net",
    instagram: "https://instagram.com/defzz_real",
  },
  author: {
    name: "Defzz",
    number: "6282375197753",
    whatsapp: "6282375197753@s.whatsapp.net",
    instagram: "https://instagram.com/defzz_real",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContacts: false,
    },
  },
};
